# Rana MZ
This Is Facebook Cloning And Useful Tools Purely Codded By RANA MZ.
<h1>You Can Randomly Clone Facebook Account By This MultiBruteForce Attack</h1>
#Commands_To_Run_This_Tool
1-pkg update && pkg upgrade
2-pkg install python && pkg install python2
3-pkg install git

------------------------------------------------------------------------------------------
Usage :-
1- After Installing The Above Commands Login Your Account
2-You Can You Use it On Your Own Risk
3-Iam Not Responsible For Any Illegal Activity Performed By User
-------------------------------------------------------------------------------------------
Other Important Tools Will Be Installed Automatically Through Script.So Don't Worry.
If You Need Any Help You Can Contact Me On Facebook.
-------------------------------------------------------------------------------------------
This Tools Is Workable In These Platforms Or OS
1-Linux(PC)
2-Termux(Android)
3-Userland(Android)
4-ParrotOs(PC)
-------------------------------------------------------------------------------------------
Disclaimer:
1-This Github Account Or Owner Does Not Promote Any Illegal Activities.
2-This Presentation Is For Educational Purposes Only.
3-The Owner Is Not Responsible For Any Illegal Activities Or Loss.
4-Editing Of Any Part Is Allowed By Owner.You Should Have Permission From Owner To Do That.
-------------------------------------------------------------------------------------------
Owner : RANA MZ
